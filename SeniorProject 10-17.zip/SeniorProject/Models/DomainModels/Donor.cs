﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace SeniorProject.Models
{
    public class Donor
    {
        public int DonorID { get; set; }

        [Required(ErrorMessage = "Please enter a first name.")]
        [StringLength(200)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name.")]
        [MaxLength(200)]
        [Remote("Validation", "Area",
            AdditionalFields = "FirstName, Operation")]
        public string LastName { get; set; }

        public int PaymentID { get; set; }

        public ICollection<Donor> Donors { get; set; }
    }
}
