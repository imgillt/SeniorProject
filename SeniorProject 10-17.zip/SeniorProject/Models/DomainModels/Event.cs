﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace SeniorProject.Models
{
    public class Event
    {
        [MaxLength(10)]
        [Required(ErrorMessage = "Please enter an event id.")]
        [Remote("CheckEvent", "Validation", "Area")]
        public string EventID { get; set; }
        
        [StringLength(25)]
        [Required(ErrorMessage = "Please enter an event name.")]
        public string EventName { get; set; }
    }
}