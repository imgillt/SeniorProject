﻿using Newtonsoft.Json;

namespace SeniorProject.Models
{
    public class VolunteerGridDTO : GridDTO
    {
        [JsonIgnore]
        public const string DefaultFilter = "all";

        public string Volunteer { get; set; } = DefaultFilter;
        public string Event { get; set; } = DefaultFilter;
        public string Date { get; set; } = DefaultFilter;
    }
}
