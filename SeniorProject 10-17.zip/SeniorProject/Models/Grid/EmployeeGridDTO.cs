﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SeniorProject.Models.Grid
{
    public class EmployeeGridDTO : GridDTO
    { 
            [JsonIgnore]
            public const string DefaultFilter = "all";

            public string EmployeeID { get; set; } = DefaultFilter;
            public string FirstName { get; set; } = DefaultFilter;
            public string LastName { get; set; } = DefaultFilter;

            public string JobTitle { get; set; } = DefaultFilter;
     }
}
*/