﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SeniorProject.Models
{
    internal class SeedVolunteers : IEntityTypeConfiguration<Volunteer>
    {
        public void Configure(EntityTypeBuilder<Volunteer> entity)
        {
            entity.HasData(
                new Volunteer { VolunteerID = 1, FirstName = "Derrick", LastName = "Lee" },
                new Volunteer { VolunteerID = 2, FirstName = "Kris", LastName = "Bryant" },
                new Volunteer { VolunteerID = 3, FirstName = "Anthony", LastName = "Rizzo" },
                new Volunteer { VolunteerID = 4, FirstName = "Allison", LastName = "Jones" },
                new Volunteer { VolunteerID = 5, FirstName = "Tina", LastName = "Anderson" },
                new Volunteer { VolunteerID = 6, FirstName = "Brittany", LastName = "Felix" }
            );
        }
    }

}
