﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SeniorProject.Models
{
    internal class SeedEvents : IEntityTypeConfiguration<Event>
    {
        public void Configure(EntityTypeBuilder<Event> entity)
        {
            entity.HasData(
                new Event { EventID = "1", EventName = "Community Roadside Pickup" },
                new Event { EventID = "2", EventName = "Recycling Drive" },
                new Event { EventID = "3", EventName = "Save our Habitat Fundraising Drive" }
            );
        }
    }

}
