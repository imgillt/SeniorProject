﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SeniorProject.Models
{
    internal class SeedEmployee : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> entity)
        {
            entity.HasData(
                new Employee { EmployeeId = 1, FirstName = "Tom", LastName = "Gill", JobTitle = "CEO" },
                new Employee { EmployeeId = 2, FirstName = "Nikolaus", LastName = "Henry", JobTitle = "CFO" },
                new Employee { EmployeeId = 3, FirstName = "Thomas", LastName = "Ringenary", JobTitle = "CTO" },
                new Employee { EmployeeId = 4, FirstName = "Beau", LastName = "Sanders", JobTitle = "Boardmember" },
                new Employee { EmployeeId = 5, FirstName = "Jane", LastName = "Doe", JobTitle = "Boardmember" },
                new Employee { EmployeeId = 6, FirstName = "John", LastName = "Smith", JobTitle = "Boardmember" }
            );
        }
    }

}