﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SeniorProject.Models
{
    internal class SeedDonors : IEntityTypeConfiguration<Donor>
    {
        public void Configure(EntityTypeBuilder<Donor> entity)
        {
            entity.HasData(
                new Donor { DonorID = 1, FirstName = "Aaron", LastName = "Rodgers" },
                new Donor { DonorID = 2, FirstName = "Antonio", LastName = "Freeman" },
                new Donor { DonorID = 3, FirstName = "Randall", LastName = "Cobb" },
                new Donor { DonorID = 4, FirstName = "Rebecca", LastName = "Smith" },
                new Donor { DonorID = 5, FirstName = "Tiffany", LastName = "Jefferson" },
                new Donor { DonorID = 6, FirstName = "Mary", LastName = "Lee" }
            );
        }
    }

}
