﻿/*using System.Linq;

namespace SeniorProject.Models
{
    public class SeniorProjectUnitOfWork : IBookstoreUnitOfWork
    {
        private SeniorProjectContext context { get; set; }
        public SeniorProjectUnitOfWork(SeniorProjectContext ctx) => context = ctx;

        private Repository<Volunteer> volunteerData;
        public Repository<Volunteer> Volunteer {
            get {
                if (volunteerData == null)
                    volunteerData = new Repository<Volunteer>(context);
                return volunteerData;
            }
        }

        private Repository<Employee> employeeData;
        public Repository<Employee> Employees {
            get {
                if (employeeData == null)
                    employeeData = new Repository<Employee>(context);
                return employeeData;
            }
        }

        private Repository<Donor> donorData;
        public Repository<Donor> Donors {
            get {
                if (donorData == null)
                    donorData = new Repository<Donor>(context);
                return donorData;
            }
        }

        private Repository<Event> eventData;
        public Repository<Event> Events
        {
            get {
                if (eventData == null)
                    eventData = new Repository<Event>(context);
                return eventData;
            }
        }

        public void DeleteCurrentBookAuthors(Volunteer volunteer)
        {
            var currentEmployee = Donor.List(new QueryOptions<Donor> {
                Where = dnr => dnr.DonorID == volunteer.VolunteerID
            });
            foreach (Donor ba in currentEmployee) {
                Donor.Delete(ba);
            }
        }

        public void LoadNewBookAuthors(Volunteer volunteer, int[] employeeid)
        {
            volunteer.VolunteerID = Donor.Select(i =>
                new Donor { volunteer = volunteer, DonorID = i })
                .ToList();
        }

        public void Save() => context.SaveChanges();
    }
}*/