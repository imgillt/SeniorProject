﻿/*namespace SeniorProject.Models
{
    public interface IBookstoreUnitOfWork
    {
        Repository<Volunteer> Books { get; }
        Repository<Employee> Authors { get; }
        Repository<BookAuthor> BookAuthors { get; }
        Repository<Event> Genres { get; }

        void DeleteCurrentBookAuthors(Volunteer book);
        void LoadNewBookAuthors(Volunteer book, int[] authorids);
        void Save();
    }
}*/
