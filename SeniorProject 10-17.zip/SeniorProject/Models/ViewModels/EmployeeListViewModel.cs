﻿using System.Collections.Generic;

namespace SeniorProject.Models
{
    public class EmployeeListViewModel
    {
        public IEnumerable<Employee> Employees { get; set; }
        //public RouteDictionary CurrentRoute { get; set; }
    }
}
